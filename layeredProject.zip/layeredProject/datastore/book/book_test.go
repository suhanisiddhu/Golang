package book

import (
	//"context"
	"database/sql"
	"errors"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/stretchr/testify/assert"
	"layeredProject/driver"
	"layeredProject/entities"
	"log"
	//"strconv"
	"testing"
)

func NewMock(t *testing.T) (*sql.DB, sqlmock.Sqlmock) {
	db, mock, err := sqlmock.New(sqlmock.QueryMatcherOption(sqlmock.QueryMatcherEqual))
	if err != nil {
		log.Fatalf("error while establishing dummy connection for booksDB: %v", err)
	}

	return db, mock
}

func TestGetAllBook(t *testing.T) {
	db, mock := NewMock(t)
	b := New(db)
	Testcases := []struct {
		desc         string
	    input        entities.Book
	     lastInserted int64
	     affectedRow  int64
		 err          error
} {
		{"Book successfully posted", entities.Book{1, 1, "3 mistakes", "penguin", "25/04/2001", entities.Author{1, "", "", "", ""}}, 1, 1, nil},
		{"book already exists ", entities.Book{1, 1, "3 mistakes", "penguin", "25/04/2001", entities.Author{1, "", "", "", ""}}, 1, 0, errors.New("book already present")},

	}
   for _, tc := range Testcases {
    mock.ExpectExec("INSERT INTO book(bookId, authorId, title, publication, publishedDate)VALUES (?,?,?,?,?)").
	WithArgs(tc.input.BookID, tc.input.Author.AuthorID, tc.input.Title, tc.input.Publication, tc.input.PublishedDate).
    WillReturnResult(sqlmock.NewResult(tc.lastInserted, tc.affectedRow)).WillReturnError(tc.err)
    _, err := b.GetAllBook(tc.input)
    assert.Equal(t, tc.err, err, "Test failed: %v", tc.desc)
}
/*for _, tc := range Testcases {

	DB := driver.Connection()
	bookStore := New(DB)

	book := bookStore.GetAllBook(tc.title, tc.includeAuthor)

	if !reflect.DeepEqual(book, tc.expected) {
		t.Errorf("failed for %v\n", tc.desc)
	}
}*/
}

func TestGetBookByID(t *testing.T) {
	Testcases := []struct {
		desc     string
		targetID int

		expected entities.Book
	}{
		{"getting book by id",
			1, entities.Book{1, 1, "jk rowling", "penguin",
				"25/04/2000", entities.Author{1, "suhani", "siddhu", "25/04/2001", "roli"}}},

		{"invalid id", -1, entities.Book{}},
	}

	for _, tc := range Testcases {

		DB := driver.Connection()
		bookStore := New(DB)

		book := bookStore.GetBookByID(tc.targetID)

		if book != tc.expected {
			t.Errorf("failed for %v\n", tc.desc)
		}
	}
}

func TestPostBook(t *testing.T) {
	db, mock := NewMock(t)
	b := New(db)
	testcases := []struct {
		desc         string
		body         *entities.Book
		lastInserted int64
		affectedRow  int64
		err          error
	}{

		{"valid book", &entities.Book{8, 3, "3 mistakes", "penguin", "25/04/2001", entities.Author{3, "", "", "", ""}}, 8, 1, nil},
		{"book already exists", &entities.Book{8, 3, "3 mistakes", "penguin", "25/04/2001", entities.Author{3, "", "", "", ""}}, 8, 1, errors.New("already exists")},
	}
	for _, tc := range testcases {
		mock.ExpectExec("insert into book(authorId,title,publication,publishedDate)values(?,?,?,?)").
			WithArgs(tc.body.Author.AuthorID, tc.body.Title, tc.body.Publication, tc.body.PublishedDate).
			WillReturnResult(sqlmock.NewResult(tc.lastInserted, tc.affectedRow)).WillReturnError(tc.err)
		_, err := b.PostBook(tc.body)
		assert.Equal(t, tc.err, err, "Test failed: %v", tc.desc)
	}
	/*for _, tc := range testcases {

		DB := driver.Connection()
		bookStore := New(DB)

		id, err := bookStore.PostBook(&tc.body)

		if id == 0 && tc.err != err {
			t.Errorf("failed for %v\n", tc.desc)
		}
	}*/

}

func TestPutBook(t *testing.T) {
	testcases := []struct {
		desc         string
		body         *entities.Book
		lastInserted int64
		affectedRow  int64
		err          error
	}{

		{"updating book", &entities.Book{4, 1, "JK", "penguin",
			"25/04/2000", entities.Author{1, "suhani", "siddhu", "25/04/2001", "roli"}}, 7, 1, nil},
		{"updating book", &entities.Book{4, 1, "JK", "penguin",
			"25/04/2000", entities.Author{1, "suhani", "siddhu", "25/04/2001", "roli"}}, 7, 1, nil},
	}

	for _, tc := range testcases {
		db, mock := NewMock(t)
		b := New(db)
		newID, err := (tc.body.BookID,errors.New("wrong"))

		mock.ExpectQuery("SELECT COUNT(*) FROM book WHERE bookId=?").WithArgs(newID).
			WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(1)).WillReturnError(tc.err)

		mock.ExpectExec("UPDATE book SET bookId=?, authorId=?, title=?, publication=?, publishedDate=? WHERE bookId=?").
			WithArgs(newID, tc.body.Author.AuthorID, tc.body.Title, tc.body.Publication, tc.body.PublishedDate, newID).
			WillReturnResult(sqlmock.NewResult(tc.lastInserted, tc.affectedRow)).WillReturnError(tc.err)

		mock.ExpectExec("INSERT INTO book(bookId, authorId, title, publication, publishedDate)VALUES (?,?,?,?,?)").
			WithArgs(newID, tc.body.Author.AuthorID, tc.body.Title, tc.body.Publication, tc.body.Publication).WillReturnResult(sqlmock.NewResult(tc.lastInserted, tc.affectedRow)).WillReturnError(tc.err)

		_, err = b.PutBook(tc.body)

		assert.Equal(t, tc.err, err, "Test failed : %v", tc.desc)
	}
}

/*DB := driver.Connection()
	bookStore := New(DB)

	_, err := bookStore.PutBook(&tc.body, tc.targetID)

	if tc.expectedErr != err {
		t.Errorf("failed for %v\n", tc.desc)
	}
}*/

func TestDeleteBook(t *testing.T) {
	testcases := []struct {
		desc     string
		targetID int
		err      error
	}{
		{"valid id", 2, nil},
		{"invalid id", 10, errors.New("invalid id")},
	}

	for _, tc := range testcases {
		DB := driver.Connection()
		bookStore := New(DB)

		id, err := bookStore.DeleteBook(tc.targetID)

		if id == 0 && tc.err != err {
			t.Errorf("failed for %v\n", tc.desc)
		}
	}

}
