package entities

type Author struct {
	AuthorID  int    `json:"authorID,omitempty"`
	FirstName string `json:"firstName,omiempty"`
	LastName  string `json:"lastName,omitempty"`
	DOB       string `json:"DOB,omitempty"`
	PenName   string `json:"penName,omitempty"`
}
